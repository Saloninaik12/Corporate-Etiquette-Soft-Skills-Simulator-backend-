package com.corporate_etiquette_mvp.config;

public class DatabaseConfig {

}

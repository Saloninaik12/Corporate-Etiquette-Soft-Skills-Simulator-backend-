package com.corporate_etiquette_mvp.Dto;

public class UserDto {

}
